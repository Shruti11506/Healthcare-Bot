# app.py
# Healthcare FAQ Bot - Backend Server
# Uses Flask + Google Gemini API (FREE tier!)

from flask import Flask, request, jsonify, send_from_directory
from google import genai
from google.genai import types
import os
from medical_data import get_compressed_context, find_relevant_symptoms, MEDICAL_KNOWLEDGE_BASE

app = Flask(__name__, static_folder='.')

# ============================================================
# IMPORTANT: Set your Gemini API key here OR as environment variable
# Get your FREE key from: https://aistudio.google.com/apikey
#
# Option 1: Set as environment variable (RECOMMENDED):
#   Windows: set GEMINI_API_KEY=your_key_here
#   Mac/Linux: export GEMINI_API_KEY=your_key_here
# Option 2: Replace "your_api_key_here" below
# ============================================================
API_KEY = os.environ.get("GEMINI_API_KEY", "your_api_key_here")

client = genai.Client(api_key=API_KEY)

# Store conversation history per session
conversation_histories = {}

SYSTEM_PROMPT = """You are MediBot, a friendly and knowledgeable Healthcare FAQ Assistant.
You help users understand common symptoms, home remedies, and when to seek professional medical help.

RULES:
1. Always be empathetic and caring in your responses
2. Use the provided medical database as your PRIMARY source
3. Give clear, concise answers (avoid overly long responses)
4. ALWAYS remind users that serious symptoms need a real doctor
5. For ANY emergency symptoms (chest pain, difficulty breathing, stroke signs), immediately say to call emergency services
6. Structure responses with: What it might be -> Home remedies -> When to see a doctor
7. Keep responses friendly and easy to understand (avoid heavy medical jargon)
8. If unsure, say so honestly and recommend professional consultation

MEDICAL KNOWLEDGE BASE:
{context}"""

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        user_message = data.get('message', '').strip()
        session_id = data.get('session_id', 'default')

        if not user_message:
            return jsonify({'error': 'Empty message'}), 400

        # Check for emergency keywords first
        emergency_keywords = ['chest pain', "can't breathe", 'stroke', 'unconscious',
                              'overdose', 'severe bleeding', 'heart attack']
        is_emergency = any(kw in user_message.lower() for kw in emergency_keywords)

        if is_emergency:
            return jsonify({
                'response': 'EMERGENCY ALERT\n\nThe symptoms you described may be serious. Please call emergency services (911/108) immediately or go to the nearest emergency room.\n\nDo NOT wait or try home remedies for these symptoms.',
                'is_emergency': True,
                'tokens_used': 0
            })

        # Get relevant symptoms (TOKEN COMPRESSION)
        relevant_symptoms = find_relevant_symptoms(user_message)

        if len(relevant_symptoms) < len(MEDICAL_KNOWLEDGE_BASE["symptoms"]):
            context_parts = []
            for symptom, sdata in relevant_symptoms.items():
                context_parts.append(
                    f"[{symptom.upper()}] Causes: {', '.join(sdata['causes'][:3])} | "
                    f"Treatments: {', '.join(sdata['treatments'][:3])} | "
                    f"See Doctor: {', '.join(sdata['seek_doctor'][:2])}"
                )
            context = "\n".join(context_parts)
            context += f"\n\nEmergency: {', '.join(MEDICAL_KNOWLEDGE_BASE['emergency_symptoms'][:4])}"
        else:
            context = get_compressed_context()

        # Initialize or get conversation history
        if session_id not in conversation_histories:
            conversation_histories[session_id] = []

        history = conversation_histories[session_id]

        # Keep only last 6 messages to save tokens
        if len(history) > 6:
            history = history[-6:]
            conversation_histories[session_id] = history

        # Build Gemini contents list from history + new message
        contents = []
        for msg in history:
            role = msg['role'] if msg['role'] == 'user' else 'model'
            contents.append(
                types.Content(
                    role=role,
                    parts=[types.Part(text=msg['content'])]
                )
            )
        contents.append(
            types.Content(
                role='user',
                parts=[types.Part(text=user_message)]
            )
        )

        # Call Gemini API
        response = client.models.generate_content(
            model='gemini-2.0-flash',
            contents=contents,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT.format(context=context),
                max_output_tokens=500,
                temperature=0.7,
            )
        )

        assistant_message = response.text
        tokens_used = 0
        try:
            tokens_used = response.usage_metadata.total_token_count
        except:
            pass

        # Save to history
        history.append({'role': 'user', 'content': user_message})
        history.append({'role': 'model', 'content': assistant_message})

        return jsonify({
            'response': assistant_message,
            'is_emergency': False,
            'tokens_used': tokens_used,
            'context_tokens': len(context.split())
        })

    except Exception as e:
        err = str(e)
        return jsonify({'error': f'Server error: {err}'}), 500

@app.route('/reset', methods=['POST'])
def reset_chat():
    data = request.get_json()
    session_id = data.get('session_id', 'default')
    if session_id in conversation_histories:
        del conversation_histories[session_id]
    return jsonify({'message': 'Chat history cleared'})

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'ok',
        'api_key_set': API_KEY != "your_api_key_here",
        'model': 'gemini-2.0-flash'
    })

if __name__ == '__main__':
    print("=" * 50)
    print("Healthcare FAQ Bot Starting...")
    print("Powered by Google Gemini (FREE!)")
    print("=" * 50)
    if API_KEY == "your_api_key_here":
        print("WARNING: No API key set!")
        print("Get your FREE key from:")
        print("https://aistudio.google.com/apikey")
        print("Then run: set GEMINI_API_KEY=your_key_here")
    else:
        print("Gemini API Key detected")
    print("\nOpen your browser and go to:")
    print("http://localhost:5000")
    print("\nPress Ctrl+C to stop the server")
    print("=" * 50)
    app.run(debug=True, port=5000)
